#include "widget.h"
#include "ui_widget.h"


Widget::Widget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Widget)
{
    ui->setupUi(this);
    m_webEngineView = new QWebEngineView(this);
    ui->gridLayout->addWidget(m_webEngineView, 1, 0);
    connect(m_webEngineView, &QWebEngineView::urlChanged, this, &Widget::setUrl);
}

Widget::~Widget()
{
    delete ui;
}

void Widget::on_urlLineEdit_returnPressed()
{
    m_webEngineView->setUrl(QUrl(ui->urlLineEdit->text()));
}

void Widget::setUrl(const QUrl &url)
{
    ui->urlLineEdit->setText(url.toString());
}
