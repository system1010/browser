#ifndef WIDGET_H
#define WIDGET_H

#include <QWidget>
#include <QWebEngineView>
#include <QUrl>

namespace Ui {
class Widget;
}

class Widget : public QWidget
{
    Q_OBJECT

public:
    explicit Widget(QWidget *parent = 0);
    ~Widget();

private slots:
    void on_urlLineEdit_returnPressed();
    void setUrl(const QUrl &url);

private:
    Ui::Widget *ui;
    QWebEngineView *m_webEngineView;
};

#endif // WIDGET_H
